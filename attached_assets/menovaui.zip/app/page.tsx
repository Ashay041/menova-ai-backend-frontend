import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function WelcomePage() {
  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <div className="bg-[#ffe18b] rounded-full w-16 h-16 flex items-center justify-center mr-4">
          <span className="text-black font-medium">M</span>
        </div>
        <div>
          <h2 className="text-xl font-bold">Menova.ai</h2>
          <p className="text-sm text-gray-600">Your personalized menopause companion</p>
        </div>
      </div>

      <p className="text-sm text-gray-500 mb-1">You are not alone in this journey</p>
      <p className="text-sm text-gray-500 mb-6">Connect with a supportive community</p>

      <div className="space-y-3">
        <Link href="/assessment">
          <Button className="w-full bg-[#f26158] hover:bg-[#e05048] text-white">Take Assessment</Button>
        </Link>
        <Link href="/signup">
          <Button className="w-full bg-[#ffe18b] hover:bg-[#ffd86b] text-black">Create Account</Button>
        </Link>
        <Link href="/login">
          <Button variant="outline" className="w-full">
            Sign In
          </Button>
        </Link>
        <p className="text-xs text-center text-gray-500">Already have an account?</p>
      </div>
    </div>
  )
}

