"use client"

import Link from "next/link"
import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

export default function BetterSleepPlanPage() {
  const [experience, setExperience] = useState("")

  return (
    <div className="p-6 pb-20">
      <div className="flex items-center mb-6">
        <Link href="/wellness-plans" className="text-[#f26158]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h1 className="text-2xl font-bold mx-auto">Better Sleep Plan</h1>
      </div>

      <div className="mb-6">
        <div className="text-lg mb-2">Day 14 of 21</div>
        <div className="relative h-4 bg-[#ffd7d0] rounded-full mb-2">
          <div className="absolute top-0 left-0 h-4 w-[67%] bg-[#f26158] rounded-full"></div>
        </div>
        <div className="flex justify-between">
          <div className="text-lg font-medium">67% complete</div>
          <div className="text-lg text-[#f26158]">40 participants</div>
        </div>
      </div>

      <div className="border-2 border-[#f26158] rounded-xl p-5 mb-8 relative">
        <h2 className="text-xl font-bold mb-4">Today: Sleep Environment</h2>
        <p className="text-base mb-3">Keep your bedroom temperature between 65-68°F (18-20°C).</p>
        <p className="text-base mb-3">Use blackout curtains or an eye mask to eliminate light disturbances.</p>
        <p className="text-base mb-3">Try using a white noise machine to mask disruptive sounds.</p>

        <div className="flex justify-end mt-4">
          <Button className="bg-[#f26158] text-white text-base rounded-full px-6">Mark Complete</Button>
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Community Progress</h2>
        <div className="border border-gray-200 rounded-xl p-5">
          <div className="flex gap-6 mb-3">
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-[#f26158]"></div>
              <span className="text-sm">You</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-[#ffe18b]"></div>
              <span className="text-sm">Community Average</span>
            </div>
          </div>

          <div className="h-40 w-full relative mb-2">
            {/* Graph visualization */}
            <svg width="100%" height="100%" viewBox="0 0 400 150" preserveAspectRatio="none">
              {/* Your line */}
              <path d="M0,120 C50,100 100,80 150,60 S250,30 400,20" fill="none" stroke="#f26158" strokeWidth="3" />
              {/* Community average line */}
              <path
                d="M0,130 C50,120 100,110 150,90 S250,70 400,50"
                fill="none"
                stroke="#ffe18b"
                strokeWidth="3"
                strokeDasharray="5,5"
              />
            </svg>
          </div>

          <div className="flex justify-between text-sm text-gray-500">
            <span>Day 1</span>
            <span>5</span>
            <span>10</span>
            <span>14</span>
            <span>17</span>
            <span>21</span>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Discussion</h2>

        <div className="mb-4">
          <div className="flex gap-3 mb-3">
            <Avatar className="w-10 h-10 bg-[#ffd7d0] text-[#f26158]">
              <AvatarFallback>K</AvatarFallback>
            </Avatar>
            <div>
              <div className="text-base font-medium">Karen M.</div>
              <p className="text-base">
                I've been using a cooling pad under my sheets and it's made a huge difference!
              </p>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex gap-3">
            <Avatar className="w-10 h-10 bg-[#ffd7d0] text-[#f26158]">
              <AvatarFallback>T</AvatarFallback>
            </Avatar>
            <div>
              <div className="text-base font-medium">Tina L.</div>
              <p className="text-base">The white noise machine suggestion changed my sleep quality completely!</p>
            </div>
          </div>
        </div>

        <div className="relative">
          <input
            placeholder="Share your experience..."
            className="w-full text-base border border-gray-300 rounded-full py-3 px-5"
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
          />
        </div>
      </div>
    </div>
  )
}

