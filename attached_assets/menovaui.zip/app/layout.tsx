import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import { cn } from "@/lib/utils"
import NavigationBar from "@/components/navigation-bar"
import { AuthProvider } from "@/contexts/auth-context"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={cn("min-h-screen bg-gray-50 font-sans antialiased", inter.className)}>
        <AuthProvider>
          <div className="max-w-md mx-auto bg-white min-h-screen relative pb-16">
            {children}
            <NavigationBar />
          </div>
        </AuthProvider>
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
