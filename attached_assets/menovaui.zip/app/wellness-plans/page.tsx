"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"

export default function WellnessPlansPage() {
  const router = useRouter()

  const handleGoToDiscussions = () => {
    router.push("/better-sleep-plan")
  }

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center mb-4">
        <Link href="/home" className="mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-500"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h2 className="text-lg font-bold">Wellness Plans</h2>
        <Badge className="bg-[#f26158] text-white text-xs ml-auto">Expert-guided</Badge>
      </div>

      <Tabs defaultValue="plans">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="plans" className="text-xs">
            Plans
          </TabsTrigger>
          <TabsTrigger value="discussions" className="text-xs" onClick={handleGoToDiscussions}>
            Discussions
          </TabsTrigger>
          <TabsTrigger value="progress" className="text-xs">
            Progress
          </TabsTrigger>
        </TabsList>

        <TabsContent value="plans">
          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">My Active Plans</h3>

            <Link href="/better-sleep-plan">
              <div className="border rounded-lg p-3 mb-3">
                <div className="flex justify-between items-center mb-1">
                  <h4 className="text-sm font-medium">Better Sleep Plan</h4>
                  <Badge className="bg-[#ffe18b] text-black text-[10px]">Go to Plan</Badge>
                </div>
                <div className="text-xs text-gray-500 mb-1">Day 14 of 21</div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="text-xs text-[#f26158]">67% complete</div>
                  <div className="text-xs text-gray-500">40 others</div>
                </div>
                <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden">
                  <div className="bg-[#f26158] h-1 rounded-full" style={{ width: "67%" }}></div>
                </div>
              </div>
            </Link>
          </div>

          <div className="mb-4">
            <h3 className="text-sm font-medium mb-2">Find A Plan</h3>

            <div className="relative mb-3">
              <Input placeholder="Search plans..." className="text-xs pl-8" />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500"
              >
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.3-4.3"></path>
              </svg>
              <Button variant="ghost" size="sm" className="absolute right-1 top-1 h-6 text-xs">
                Sort
              </Button>
            </div>

            <div className="mb-3">
              <div className="text-xs font-medium mb-2">Based on your tracked symptoms</div>

              <div className="border rounded-lg p-3 mb-2">
                <h4 className="text-sm font-medium mb-1">Hot Flash Relief</h4>
                <p className="text-xs text-gray-500 mb-1">
                  4-week program to reduce frequency and intensity of hot flashes
                </p>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">124 active participants</div>
                  <Button size="sm" className="bg-[#f26158] text-white text-xs">
                    Join Plan
                  </Button>
                </div>
              </div>

              <div className="border rounded-lg p-3">
                <h4 className="text-sm font-medium mb-1">Brain Fog Clarity</h4>
                <p className="text-xs text-gray-500 mb-1">
                  2-week cognitive enhancement plan with memory exercises and supplements
                </p>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">67 active participants</div>
                  <Button size="sm" className="bg-[#f26158] text-white text-xs">
                    Join Plan
                  </Button>
                </div>
              </div>
            </div>

            <Button variant="outline" size="sm" className="w-full text-xs">
              Browse All Plans
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

