"use client"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useRouter } from "next/navigation"

export default function CommunityPage() {
  const router = useRouter()

  const handleTabChange = (value: string) => {
    if (value === "blogs") {
      router.push("/community/blogs")
    }
  }

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center mb-4">
        <Link href="/home" className="mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-500"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h2 className="text-lg font-bold">Community</h2>
      </div>

      <Tabs defaultValue="discussions" onValueChange={handleTabChange}>
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="discussions" className="text-xs">
            Discussions
          </TabsTrigger>
          <TabsTrigger value="blogs" className="text-xs">
            Blogs
          </TabsTrigger>
          <TabsTrigger value="content" className="text-xs">
            My Content
          </TabsTrigger>
        </TabsList>

        <TabsContent value="discussions">
          <div className="mb-4">
            <div className="relative mb-4">
              <Input placeholder="Search community..." className="text-xs pl-8" />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500"
              >
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.3-4.3"></path>
              </svg>
            </div>

            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-medium">Popular Topics</h3>
              <Button variant="ghost" size="sm" className="text-xs h-6">
                Filter ▾
              </Button>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline" className="text-xs">
                Hot Flashes
              </Badge>
              <Badge variant="outline" className="text-xs">
                Insomnia
              </Badge>
              <Badge variant="outline" className="text-xs">
                Anxiety
              </Badge>
            </div>

            <div className="space-y-4">
              <div className="border rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback>K</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-sm font-medium">Sleep Tips for Night Sweats</h4>
                    <div className="text-xs text-gray-500">
                      Karen shares her experience with cooling pads and temperature regulation
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">2 days ago • 8 comments</div>
                  <Badge variant="outline" className="text-xs">
                    Sleep
                  </Badge>
                </div>
              </div>

              <div className="border rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback>R</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-sm font-medium">Alternative to HRT?</h4>
                    <div className="text-xs text-gray-500">
                      Rebecca is looking for natural alternatives to hormone replacement therapy
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">3 days ago • 12 comments</div>
                  <Badge variant="outline" className="text-xs">
                    Treatments
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

