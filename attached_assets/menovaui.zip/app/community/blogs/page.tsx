"use client"

import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useRouter } from "next/navigation"

export default function CommunityBlogsPage() {
  const router = useRouter()

  const handleTabChange = (value: string) => {
    if (value === "discussions") {
      router.push("/community")
    }
  }

  const handleBlogClick = () => {
    router.push("/blog-post")
  }

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center mb-4">
        <Link href="/home" className="mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-500"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h2 className="text-lg font-bold">Community</h2>
      </div>

      <Tabs defaultValue="blogs" onValueChange={handleTabChange}>
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="discussions" className="text-xs">
            Discussions
          </TabsTrigger>
          <TabsTrigger value="blogs" className="text-xs">
            Blogs
          </TabsTrigger>
          <TabsTrigger value="content" className="text-xs">
            My Content
          </TabsTrigger>
        </TabsList>

        <TabsContent value="blogs">
          <div className="mb-4">
            <div className="relative mb-4">
              <Input placeholder="Search blogs..." className="text-xs pl-8" />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500"
              >
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.3-4.3"></path>
              </svg>
            </div>

            <div className="space-y-4">
              <div className="border rounded-lg p-3 cursor-pointer" onClick={handleBlogClick}>
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback>M</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-sm font-medium">My Journey with Night Sweats</h4>
                    <div className="text-xs text-gray-500">
                      Maria shares her experience finding relief from night sweats through lifestyle changes...
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">Feb 15 • 4 min read • 36 comments</div>
                  <Badge variant="outline" className="text-xs">
                    Sleep
                  </Badge>
                </div>
                <div className="text-xs text-[#f26158] mt-1">Related: Better Sleep Plan • 40 participants →</div>
              </div>

              <div className="border rounded-lg p-3 cursor-pointer" onClick={handleBlogClick}>
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback>J</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-sm font-medium">How I Managed Mood Swings</h4>
                    <div className="text-xs text-gray-500">
                      Jane's personal story about finding balance and managing emotional ups and downs...
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">Feb 20 • 5 min read • 29 comments</div>
                  <Badge variant="outline" className="text-xs">
                    Mood
                  </Badge>
                </div>
                <div className="text-xs text-[#f26158] mt-1">Related: Anxiety Management Plan • 86 participants →</div>
              </div>

              <div className="border rounded-lg p-3 cursor-pointer" onClick={handleBlogClick}>
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback>S</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-sm font-medium">Brain Fog: What Worked for Me</h4>
                    <div className="text-xs text-gray-500">
                      Sarah discusses supplements and exercises that helped clear her thinking...
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">Feb 22 • 6 min read • 42 comments</div>
                  <Badge variant="outline" className="text-xs">
                    Cognitive
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

