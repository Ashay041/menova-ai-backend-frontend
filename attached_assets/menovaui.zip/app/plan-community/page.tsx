"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function PlanCommunityPage() {
  const router = useRouter()

  const handleGoToPlan = () => {
    router.push("/better-sleep-plan")
  }

  const handleShareExperience = () => {
    router.push("/community")
  }

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center mb-4">
        <Link href="/home" className="mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-500"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h2 className="text-lg font-bold">Plan Community</h2>
        <Badge className="bg-[#f26158] text-white text-xs ml-auto">40 participants • 14 new posts today</Badge>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="all" className="text-xs">
            All Posts
          </TabsTrigger>
          <TabsTrigger value="success" className="text-xs">
            Success Stories
          </TabsTrigger>
          <TabsTrigger value="questions" className="text-xs">
            Questions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="space-y-3">
            <div className="flex gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>K</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <div className="text-sm font-medium">Karen M.</div>
                  <div className="text-xs text-gray-500">Day 14</div>
                </div>
                <p className="text-xs mb-1">
                  I've been using a cooling pad under my sheets and it's made a huge difference! My night sweats have
                  reduced by at least 70%.
                </p>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">Posted 2 days ago • 8 replies</div>
                  <Button variant="ghost" size="sm" className="text-xs h-6">
                    Like
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>T</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <div className="text-sm font-medium">Tina L.</div>
                  <div className="text-xs text-gray-500">Day 16</div>
                </div>
                <p className="text-xs mb-1">
                  The white noise machine suggestion from Day 8 has changed my sleep completely! I'm now getting 7+
                  hours of uninterrupted sleep.
                </p>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">Posted yesterday • 3 replies</div>
                  <Button variant="ghost" size="sm" className="text-xs h-6">
                    Like
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <Button className="bg-[#ffe18b] text-black hover:bg-[#ffd86b] text-xs w-full" onClick={handleGoToPlan}>
              Go to Plan
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      <Button
        className="w-full mt-4 bg-[#ffe18b] text-black hover:bg-[#ffd86b] text-xs"
        onClick={handleShareExperience}
      >
        Share Your Experience
      </Button>
    </div>
  )
}

