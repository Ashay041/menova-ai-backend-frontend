"use client"

import type React from "react"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import ProtectedRoute from "@/components/protected-route"

// Define types for our messages
type Message = {
  id?: string
  sender: "user" | "ai"
  content: string
}

export default function ChatPage() {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<Message[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()

  // Fetch chat history when component mounts
  useEffect(() => {
    const fetchChatHistory = async () => {
      if (!user) return

      try {
        const response = await fetch(`/api/chat/history?userId=${user._id}`)

        if (!response.ok) {
          throw new Error("Failed to fetch chat history")
        }

        const data = await response.json()

        if (data.messages && data.messages.length > 0) {
          const formattedMessages = data.messages.map((msg: any) => ({
            id: msg._id,
            sender: msg.sender as "user" | "ai",
            content: msg.content,
          }))
          setMessages(formattedMessages)
        } else {
          // If no messages, add initial greeting
          setMessages([
            {
              id: "initial-greeting",
              sender: "ai",
              content: "Hi there! I'm your Menova assistant. How can I help with your menopause journey today?",
            },
          ])
        }
      } catch (err) {
        console.error("Failed to fetch chat history:", err)
        // Add initial greeting if fetch fails
        setMessages([
          {
            id: "initial-greeting",
            sender: "ai",
            content: "Hi there! I'm your Menova assistant. How can I help with your menopause journey today?",
          },
        ])
      }
    }

    fetchChatHistory()
  }, [user])

  const handleSendMessage = async () => {
    if (message.trim() && user) {
      // Add user message immediately for better UX
      const userMessage: Message = {
        id: `temp-${Date.now()}`,
        sender: "user",
        content: message,
      }

      setMessages((prev) => [...prev, userMessage])
      setIsLoading(true)
      setError(null)

      // Clear input right away
      setMessage("")

      try {
        // Send message to API
        const response = await fetch("/api/chat/message", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            userId: user._id,
            message: userMessage.content,
          }),
        })

        if (!response.ok) {
          throw new Error(`Error: ${response.status}`)
        }

        const data = await response.json()

        // Add AI response
        setMessages((prev) => [
          ...prev,
          {
            id: data.messageId,
            sender: "ai",
            content: data.responseText,
          },
        ])
      } catch (err) {
        console.error("Failed to send message:", err)
        setError("Failed to send message. Please try again.")

        // Fallback response if API fails
        setMessages((prev) => [
          ...prev,
          {
            id: `fallback-${Date.now()}`,
            sender: "ai",
            content: "I'm having trouble connecting right now. Please try again in a moment.",
          },
        ])
      } finally {
        setIsLoading(false)
      }
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !isLoading) {
      handleSendMessage()
    }
  }

  return (
    <ProtectedRoute>
      <div className="p-6 pb-20">
        <h2 className="text-xl font-bold mb-6">AI Chat</h2>

        <div className="space-y-4 mb-6 max-h-[60vh] overflow-y-auto">
          {messages.map((msg, index) =>
            msg.sender === "ai" ? (
              <div key={msg.id || index} className="flex gap-2">
                <Avatar className="w-6 h-6 bg-[#f26158] text-white">
                  <AvatarFallback>M</AvatarFallback>
                </Avatar>
                <div className="bg-gray-100 rounded-lg p-3 text-xs max-w-[80%]">
                  <p className="whitespace-pre-line">{msg.content}</p>
                </div>
              </div>
            ) : (
              <div key={msg.id || index} className="flex gap-2 justify-end">
                <div className="bg-[#ffd7d0] rounded-lg p-3 text-xs max-w-[80%]">
                  <p>{msg.content}</p>
                </div>
                <Avatar className="w-6 h-6">
                  <AvatarFallback>{user?.email?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                </Avatar>
              </div>
            ),
          )}

          {isLoading && (
            <div className="flex gap-2">
              <Avatar className="w-6 h-6 bg-[#f26158] text-white">
                <AvatarFallback>M</AvatarFallback>
              </Avatar>
              <div className="bg-gray-100 rounded-lg p-3 text-xs">
                <Loader2 className="h-4 w-4 animate-spin" />
              </div>
            </div>
          )}

          {error && <div className="text-xs text-red-500 text-center">{error}</div>}
        </div>

        <div className="flex gap-2 mb-6">
          <Link href="/better-sleep-plan">
            <Button variant="outline" className="text-xs h-8 rounded-full border-[#f26158] text-[#f26158]">
              Sleep Tips
            </Button>
          </Link>
          <Link href="/symptom-tracker">
            <Button variant="outline" className="text-xs h-8 rounded-full">
              Track Sleep
            </Button>
          </Link>
        </div>

        <div className="relative">
          <Input
            placeholder="Type a message..."
            className="pr-10 rounded-full text-xs"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoading}
          />
          <Button
            size="sm"
            className="absolute right-1 top-1 h-6 w-6 rounded-full p-0 bg-[#f26158]"
            onClick={handleSendMessage}
            disabled={isLoading || !message.trim()}
          >
            <span className="sr-only">Send</span>
            {isLoading ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4"
              >
                <path d="M12 5l7 7-7 7"></path>
              </svg>
            )}
          </Button>
        </div>
      </div>
    </ProtectedRoute>
  )
}

