"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2 } from "lucide-react"
import ProtectedRoute from "@/components/protected-route"
import Link from "next/link"

export default function ProfilePage() {
  const { user, signOut } = useAuth()
  const [profileData, setProfileData] = useState({
    fullName: "",
    menopauseStage: "",
    dateOfBirth: "",
    lastPeriodDate: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      setProfileData({
        fullName: user.fullName || "",
        menopauseStage: user.menopauseStage || "",
        dateOfBirth: user.dateOfBirth || "",
        lastPeriodDate: user.lastPeriodDate || "",
      })
    }
  }, [user])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setError(null)
    setSuccess(null)
    setIsSaving(true)

    try {
      const response = await fetch(`/api/users/${user._id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(profileData),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Failed to update profile")
        return
      }

      setSuccess("Profile updated successfully")
    } catch (err) {
      console.error("Update error:", err)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <ProtectedRoute>
      <div className="p-6 pb-20">
        <div className="flex items-center mb-6">
          <Link href="/home" className="mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-500"
            >
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
          </Link>
          <h2 className="text-xl font-bold">My Profile</h2>
        </div>

        {isLoading ? (
          <div className="flex justify-center my-8">
            <Loader2 className="h-8 w-8 animate-spin text-[#f26158]" />
          </div>
        ) : user ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && <div className="bg-red-50 text-red-500 p-3 rounded-md text-sm">{error}</div>}

            {success && <div className="bg-green-50 text-green-500 p-3 rounded-md text-sm">{success}</div>}

            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1">
                Email
              </label>
              <Input id="email" type="email" value={user.email || ""} disabled className="bg-gray-50" />
              <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
            </div>

            <div>
              <label htmlFor="fullName" className="block text-sm font-medium mb-1">
                Full Name
              </label>
              <Input
                id="fullName"
                type="text"
                value={profileData.fullName}
                onChange={(e) => setProfileData({ ...profileData, fullName: e.target.value })}
                placeholder="Enter your full name"
              />
            </div>

            <div>
              <label htmlFor="menopauseStage" className="block text-sm font-medium mb-1">
                Menopause Stage
              </label>
              <select
                id="menopauseStage"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={profileData.menopauseStage}
                onChange={(e) => setProfileData({ ...profileData, menopauseStage: e.target.value })}
              >
                <option value="">Select stage</option>
                <option value="perimenopause">Perimenopause</option>
                <option value="menopause">Menopause</option>
                <option value="postmenopause">Postmenopause</option>
                <option value="unsure">Not sure</option>
              </select>
            </div>

            <div>
              <label htmlFor="dateOfBirth" className="block text-sm font-medium mb-1">
                Date of Birth
              </label>
              <Input
                id="dateOfBirth"
                type="date"
                value={profileData.dateOfBirth}
                onChange={(e) => setProfileData({ ...profileData, dateOfBirth: e.target.value })}
              />
            </div>

            <div>
              <label htmlFor="lastPeriodDate" className="block text-sm font-medium mb-1">
                Last Period Date
              </label>
              <Input
                id="lastPeriodDate"
                type="date"
                value={profileData.lastPeriodDate}
                onChange={(e) => setProfileData({ ...profileData, lastPeriodDate: e.target.value })}
              />
            </div>

            <Button type="submit" className="w-full bg-[#f26158] hover:bg-[#e05048] text-white" disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>

            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={signOut}
              variant="outline"
              className="w-full"
              onClick={signOut}
            >
              Sign Out
            </Button>
          </form>
        ) : (
          <div className="text-center my-8">
            <p>Failed to load profile. Please try again later.</p>
          </div>
        )}
      </div>
    </ProtectedRoute>
  )
}

