"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"
import { useRouter } from "next/navigation"

export default function LogSymptomPage() {
  const router = useRouter()
  const [severity, setSeverity] = useState("moderate")
  const [timeOfDay, setTimeOfDay] = useState("evening")
  const [notes, setNotes] = useState("Had trouble falling asleep before midnight...")

  const handleJoinPlan = () => {
    router.push("/wellness-plans")
  }

  const handleSaveSymptom = () => {
    router.push("/symptom-tracker")
  }

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center mb-4">
        <Link href="/home" className="mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-500"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h2 className="text-lg font-bold">Log Symptom</h2>
        <div className="text-sm text-gray-500 ml-auto">Cancel</div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-medium mb-2">Insomnia</h3>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Severity</h4>
          <div className="flex gap-2">
            <div className="flex flex-col items-center cursor-pointer" onClick={() => setSeverity("mild")}>
              <div
                className={`w-10 h-10 rounded-full ${severity === "mild" ? "bg-[#ffd7d0]" : "bg-white border"} flex items-center justify-center mb-1`}
              >
                <div className={severity === "mild" ? "w-2 h-2 rounded-full bg-[#f26158]" : "hidden"}></div>
              </div>
              <label className="text-[10px]">Mild</label>
            </div>

            <div className="flex flex-col items-center cursor-pointer" onClick={() => setSeverity("moderate")}>
              <div
                className={`w-10 h-10 rounded-full ${severity === "moderate" ? "bg-white border-2 border-[#f26158]" : "bg-white border"} flex items-center justify-center mb-1`}
              >
                <div className={severity === "moderate" ? "w-2 h-2 rounded-full bg-[#f26158]" : "hidden"}></div>
              </div>
              <label className="text-[10px]">Moderate</label>
            </div>

            <div className="flex flex-col items-center cursor-pointer" onClick={() => setSeverity("severe")}>
              <div
                className={`w-10 h-10 rounded-full ${severity === "severe" ? "bg-[#f26158]" : "bg-white border"} flex items-center justify-center mb-1`}
              >
                <div className={severity === "severe" ? "w-2 h-2 rounded-full bg-white" : "hidden"}></div>
              </div>
              <label className="text-[10px]">Severe</label>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Time of Day</h4>
          <div className="flex gap-2">
            <div className="flex flex-col items-center cursor-pointer" onClick={() => setTimeOfDay("morning")}>
              <div
                className={`w-10 h-10 rounded-full ${timeOfDay === "morning" ? "bg-[#f26158]" : "bg-white border"} flex items-center justify-center mb-1`}
              >
                <div className={timeOfDay === "morning" ? "w-2 h-2 rounded-full bg-white" : "hidden"}></div>
              </div>
              <label className="text-[10px]">Morning</label>
            </div>

            <div className="flex flex-col items-center cursor-pointer" onClick={() => setTimeOfDay("afternoon")}>
              <div
                className={`w-10 h-10 rounded-full ${timeOfDay === "afternoon" ? "bg-[#f26158]" : "bg-white border"} flex items-center justify-center mb-1`}
              >
                <div className={timeOfDay === "afternoon" ? "w-2 h-2 rounded-full bg-white" : "hidden"}></div>
              </div>
              <label className="text-[10px]">Afternoon</label>
            </div>

            <div className="flex flex-col items-center cursor-pointer" onClick={() => setTimeOfDay("evening")}>
              <div
                className={`w-10 h-10 rounded-full ${timeOfDay === "evening" ? "bg-[#f26158]" : "bg-white border"} flex items-center justify-center mb-1`}
              >
                <div className={timeOfDay === "evening" ? "w-2 h-2 rounded-full bg-white" : "hidden"}></div>
              </div>
              <label className="text-[10px]">Evening</label>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Notes</h4>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add notes about your symptoms..."
            className="text-xs min-h-[80px] resize-none"
          />
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Recommended for Your Symptoms</h4>
          <div className="border rounded-lg p-3">
            <h5 className="text-xs font-medium mb-1">Better Sleep Plan</h5>
            <p className="text-xs text-gray-500 mb-2">
              A 21-day guided program to improve sleep quality and reduce insomnia
            </p>
            <div className="text-xs text-gray-500 mb-2">40 women currently active</div>
            <div className="flex gap-2">
              <Button size="sm" className="bg-[#f26158] text-white text-xs flex-1" onClick={handleJoinPlan}>
                Join Now
              </Button>
              <Button variant="outline" size="sm" className="text-xs flex-1">
                View Later
              </Button>
            </div>
          </div>
        </div>

        <Button size="sm" className="bg-[#f26158] text-white text-xs w-full" onClick={handleSaveSymptom}>
          Save Symptom
        </Button>

        <div className="text-xs text-center text-[#f26158] mt-2 cursor-pointer">
          View Community Stories about Insomnia
        </div>
      </div>
    </div>
  )
}

