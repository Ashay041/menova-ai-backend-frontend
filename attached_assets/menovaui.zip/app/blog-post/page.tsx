import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function BlogPostPage() {
  return (
    <div className="p-4">
      <div className="flex items-center mb-4">
        <Link href="/community" className="mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-500"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h2 className="text-lg font-bold">Blog Post</h2>
      </div>

      <div className="mb-4">
        <h3 className="text-base font-bold mb-2">My Journey with Night Sweats</h3>
        <div className="text-xs text-gray-500 mb-3">March 21, 2025</div>

        <div className="flex items-center gap-2 mb-3">
          <Avatar className="w-6 h-6">
            <AvatarFallback>M</AvatarFallback>
          </Avatar>
          <div>
            <div className="text-xs font-medium">Maria Johnson</div>
            <div className="text-[10px] text-gray-500">Feb 15, 2025 • 4 min read</div>
            <Badge variant="outline" className="text-[10px] mt-1">
              Sleep
            </Badge>
          </div>
        </div>

        <div className="text-xs space-y-3 mb-4">
          <p>
            For the past year, night sweats were disrupting my sleep and leaving me exhausted. After trying several
            approaches, I finally found relief.
          </p>

          <h4 className="font-medium">What Worked For Me</h4>
          <ol className="list-decimal pl-4 space-y-1">
            <li>
              Temperature regulation: Keeping my bedroom around 65°F and using moisture-wicking sheets made a tremendous
              difference.
            </li>
            <li>
              Evening routine: Eliminating caffeine after noon and avoiding spicy foods in the evening reduced my night
              sweats by about 70%.
            </li>
            <li>
              Stress management: Daily meditation for just 10 minutes before bed helped calm my nervous system and
              resulted in fewer disruptions.
            </li>
          </ol>
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Comments (36)</h4>

          <div className="border-b pb-2 mb-2">
            <div className="flex items-start gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>S</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-xs font-medium">Sarah M.</div>
                <p className="text-xs">
                  Thank you for sharing! I've been struggling with the same issue and will try your suggestions.
                </p>
                <div className="text-[10px] text-gray-500">Feb 22 • 3 days ago • 14 comments</div>
              </div>
              <Badge className="bg-[#f26158] text-white text-[10px] h-5">Helpful</Badge>
            </div>
          </div>

          <div>
            <div className="flex items-start gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>L</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-xs font-medium">Lisa T.</div>
                <p className="text-xs">Have you tried cooling pillows? They've been a game-changer for me!</p>
                <div className="text-[10px] text-gray-500">Feb 20 • 5 days ago • 8 comments</div>
              </div>
            </div>
          </div>
        </div>

        <div className="relative">
          <input placeholder="Add a comment..." className="w-full text-xs border rounded-full py-2 px-4 pr-10" />
          <Button size="sm" className="absolute right-1 top-1 h-6 w-6 rounded-full p-0">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-3 w-3"
            >
              <path d="M12 5l7 7-7 7"></path>
            </svg>
          </Button>
        </div>
      </div>
    </div>
  )
}

