"use client"

import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import Link from "next/link"
import { useState } from "react"

export default function AssessmentPage() {
  const [selectedOption, setSelectedOption] = useState("option2")

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <div className="bg-[#ffe18b] rounded-full w-16 h-16 flex items-center justify-center mr-4">
          <span className="text-black font-medium">M</span>
        </div>
        <div>
          <h2 className="text-xl font-bold">Menova.ai</h2>
          <p className="text-sm text-gray-600">Your personalized menopause companion</p>
        </div>
      </div>

      <p className="text-sm text-gray-500 mb-1">You are not alone in this journey</p>
      <p className="text-sm text-gray-500 mb-6">Connect with a supportive community</p>

      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-medium">Assessment</h3>
          <div className="text-xs text-gray-500">Question 1 of 3</div>
        </div>

        <div className="w-full bg-gray-200 h-1 mb-6 rounded-full overflow-hidden">
          <div className="bg-[#f26158] h-1 rounded-full" style={{ width: "33.3%" }}></div>
        </div>

        <h4 className="font-medium mb-4">When was your last period?</h4>

        <RadioGroup value={selectedOption} onValueChange={setSelectedOption} className="space-y-3">
          <div
            className={`flex items-center justify-between border rounded-lg p-3 ${selectedOption === "option1" ? "border-[#ffe18b] bg-[#fffbf0]" : ""}`}
          >
            <label htmlFor="option1" className="text-sm w-full cursor-pointer">
              Within the last month
            </label>
            <RadioGroupItem
              value="option1"
              id="option1"
              className={selectedOption === "option1" ? "border-[#ffe18b] text-[#ffe18b]" : ""}
            />
          </div>

          <div
            className={`flex items-center justify-between border rounded-lg p-3 ${selectedOption === "option2" ? "border-[#ffe18b] bg-[#fffbf0]" : ""}`}
          >
            <label htmlFor="option2" className="text-sm w-full cursor-pointer">
              1-3 months ago
            </label>
            <RadioGroupItem
              value="option2"
              id="option2"
              className={selectedOption === "option2" ? "border-[#ffe18b] text-[#ffe18b]" : ""}
            />
          </div>

          <div
            className={`flex items-center justify-between border rounded-lg p-3 ${selectedOption === "option3" ? "border-[#ffe18b] bg-[#fffbf0]" : ""}`}
          >
            <label htmlFor="option3" className="text-sm w-full cursor-pointer">
              4-12 months ago
            </label>
            <RadioGroupItem
              value="option3"
              id="option3"
              className={selectedOption === "option3" ? "border-[#ffe18b] text-[#ffe18b]" : ""}
            />
          </div>

          <div
            className={`flex items-center justify-between border rounded-lg p-3 ${selectedOption === "option4" ? "border-[#ffe18b] bg-[#fffbf0]" : ""}`}
          >
            <label htmlFor="option4" className="text-sm w-full cursor-pointer">
              Over a year ago
            </label>
            <RadioGroupItem
              value="option4"
              id="option4"
              className={selectedOption === "option4" ? "border-[#ffe18b] text-[#ffe18b]" : ""}
            />
          </div>
        </RadioGroup>
      </div>

      <div className="flex justify-between items-center mb-6">
        <Button variant="outline" className="text-gray-500">
          Back
        </Button>
        <Link href="/home">
          <Button className="bg-[#f26158] hover:bg-[#e05048] text-white">Next</Button>
        </Link>
      </div>
    </div>
  )
}

