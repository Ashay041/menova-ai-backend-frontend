"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export default function SymptomTrackerPage() {
  const router = useRouter()

  const handleGoToPlan = () => {
    router.push("/better-sleep-plan")
  }

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center mb-4">
        <Link href="/home" className="mr-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-gray-500"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
        </Link>
        <h2 className="text-lg font-bold">Symptom Tracker</h2>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="overview" className="text-xs">
            Overview
          </TabsTrigger>
          <TabsTrigger value="symptoms" className="text-xs">
            Symptoms
          </TabsTrigger>
          <TabsTrigger value="plans" className="text-xs">
            Plans
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div>
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-medium mb-2">Weekly Summary</h3>
              <span className="text-xs text-gray-500">This Week ▾</span>
            </div>

            <div className="mb-4">
              <div className="h-32 w-full bg-gray-50 rounded-lg relative mb-2">
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg width="100%" height="100%" viewBox="0 0 200 100" preserveAspectRatio="none">
                    <polyline
                      points="0,80 30,60 60,70 90,40 120,50 150,30 180,20"
                      fill="none"
                      stroke="#f26158"
                      strokeWidth="2"
                    />
                    <polyline
                      points="0,90 30,85 60,80 90,85 120,75 150,80 180,70"
                      fill="none"
                      stroke="#ffe18b"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
                <div className="absolute bottom-2 left-2 text-xs">
                  <div className="flex items-center gap-1 mb-1">
                    <div className="w-3 h-1 bg-[#f26158]"></div>
                    <span>Hot Flashes</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-1 bg-[#ffe18b]"></div>
                    <span>Sleep Quality</span>
                  </div>
                </div>
              </div>
              <div className="flex justify-between text-[10px] text-gray-500">
                <span>Mon</span>
                <span>Tue</span>
                <span>Wed</span>
                <span>Thu</span>
                <span>Fri</span>
                <span>Sat</span>
                <span>Sun</span>
              </div>
            </div>

            <div className="border rounded-lg p-3 mb-4">
              <h4 className="text-sm font-medium mb-1">Active Plan Progress</h4>
              <Link href="/better-sleep-plan" className="text-xs text-[#f26158] underline mb-2 block">
                Better Sleep Plan
              </Link>
              <div className="text-xs text-gray-500 mb-1">Day 14 of 21</div>
              <div className="flex items-center gap-2 mb-1">
                <div className="text-xs text-[#f26158]">67% complete</div>
                <div className="text-xs text-gray-500">40 others</div>
              </div>
              <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden">
                <div className="bg-[#f26158] h-1 rounded-full" style={{ width: "67%" }}></div>
              </div>
            </div>

            <div className="border rounded-lg p-3 mb-4">
              <h4 className="text-sm font-medium mb-1">Today's Sleep Task</h4>
              <p className="text-xs mb-2">Optimize bedroom temperature between 65-68°F and use blackout curtains.</p>
              <Button size="sm" className="bg-[#f26158] text-white text-xs" onClick={handleGoToPlan}>
                Go to Plan
              </Button>
            </div>

            <div className="border rounded-lg p-3 mb-4">
              <h4 className="text-sm font-medium mb-1">AI Insights</h4>
              <p className="text-xs mb-2">
                Your sleep quality is improving since starting the Better Sleep Plan. Hot flashes appear to decrease on
                days with lower room temperature.
              </p>
              <Link href="/chat" className="text-xs text-[#f26158]">
                View Full Analysis ›
              </Link>
            </div>

            <Link href="/log-symptom">
              <Button className="w-full bg-[#f26158] text-white text-xs">Log Today</Button>
            </Link>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

