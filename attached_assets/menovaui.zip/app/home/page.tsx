import Link from "next/link"

export default function HomePage() {
  return (
    <div className="p-6 pb-20">
      <h1 className="text-2xl font-bold mb-6">Home</h1>

      {/* Welcome Card */}
      <div className="bg-[#ffd7d0] rounded-2xl p-5 mb-6">
        <h2 className="text-lg font-medium mb-1">Welcome, Karen!</h2>
        <p className="text-base mb-1">You're in Perimenopause Day 45</p>
        <p className="text-base mb-2">Track your symptoms to get insights</p>
        <Link href="/assessment" className="text-[#f26158] text-base">
          Take Assessment ›
        </Link>
      </div>

      {/* Quick Access */}
      <h2 className="text-xl font-bold mb-4">Quick Access</h2>
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Link href="/log-symptom" className="block">
          <div className="bg-[#ffe18b] rounded-2xl p-6 h-full flex items-center justify-center">
            <span className="text-center text-base font-medium">Log Symptoms</span>
          </div>
        </Link>
        <Link href="/chat" className="block">
          <div className="bg-[#cbe2ea] rounded-2xl p-6 h-full flex items-center justify-center">
            <span className="text-center text-base font-medium">Ask AI Assistant</span>
          </div>
        </Link>
      </div>

      {/* Today's Insights */}
      <h2 className="text-xl font-bold mb-4">Today's Insights</h2>
      <div className="border border-gray-200 rounded-2xl p-5 mb-6">
        <p className="text-base py-1">Your sleep pattern has improved</p>
        <p className="text-base py-1">Hot flashes decreased by 30%</p>
        <p className="text-base py-1">Mood seems stable this week</p>
      </div>

      {/* Community Highlights */}
      <h2 className="text-xl font-bold mb-4">Community Highlights</h2>
      <div className="border border-gray-200 rounded-2xl p-5">
        <p className="text-base py-1">New discussion: Sleep tips</p>
        <p className="text-base py-1 mb-2">5 responses to your post</p>
        <Link href="/community" className="text-[#f26158] text-base">
          View All ›
        </Link>
      </div>
    </div>
  )
}

