import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"
import { verify } from "jsonwebtoken"
import { updateUserProfile } from "@/lib/auth"

// JWT secret should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = cookies().get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    try {
      const decoded = verify(token, JWT_SECRET) as { sub: string }

      // Check if the user is updating their own profile
      if (decoded.sub !== params.id) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
      }

      const profileData = await request.json()
      const updatedUser = await updateUserProfile(params.id, profileData)

      if (!updatedUser) {
        return NextResponse.json({ error: "User not found" }, { status: 404 })
      }

      return NextResponse.json({ user: updatedUser })
    } catch (error) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }
  } catch (error) {
    console.error("Profile update error:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}

