import { type NextRequest, NextResponse } from "next/server"
import { findUserByEmail, validatePassword } from "@/lib/auth"
import { sign } from "jsonwebtoken"
import { cookies } from "next/headers"

// JWT secret should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const user = await findUserByEmail(email)

    if (!user) {
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 })
    }

    const isValid = await validatePassword(user, password)

    if (!isValid) {
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 })
    }

    // Create a JWT token
    const { password: _, ...userWithoutPassword } = user
    const token = sign({ sub: user._id.toString(), email: user.email }, JWT_SECRET, { expiresIn: "7d" })

    // Set the token as an HTTP-only cookie
    cookies().set({
      name: "auth-token",
      value: token,
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV !== "development",
      maxAge: 60 * 60 * 24 * 7, // 1 week
    })

    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Failed to authenticate user" }, { status: 500 })
  }
}

