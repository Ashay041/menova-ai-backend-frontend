import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"
import { verify } from "jsonwebtoken"
import clientPromise from "@/lib/mongodb"

// JWT secret should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function GET(request: NextRequest) {
  try {
    const token = cookies().get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    try {
      const decoded = verify(token, JWT_SECRET) as { sub: string }
      const userId = decoded.sub

      // Get userId from query params
      const searchParams = request.nextUrl.searchParams
      const queryUserId = searchParams.get("userId")

      // Check if the user is requesting their own chat history
      if (userId !== queryUserId) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
      }

      const client = await clientPromise
      const db = client.db()

      const messages = await db
        .collection("chat_messages")
        .find({ user_id: userId })
        .sort({ created_at: 1 })
        .limit(50)
        .toArray()

      return NextResponse.json({ messages })
    } catch (error) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }
  } catch (error) {
    console.error("Chat history error:", error)
    return NextResponse.json({ error: "Failed to fetch chat history" }, { status: 500 })
  }
}

