import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"
import { verify } from "jsonwebtoken"

// The URL of your FastAPI backend
const FASTAPI_URL = process.env.FASTAPI_URL || "http://localhost:8000"

// JWT secret should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function POST(request: NextRequest) {
  try {
    const token = cookies().get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    try {
      const decoded = verify(token, JWT_SECRET) as { sub: string }
      const userId = decoded.sub

      const body = await request.json()

      // Check if the user is sending a message for themselves
      if (userId !== body.userId) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
      }

      // Forward the request to FastAPI
      const response = await fetch(`${FASTAPI_URL}/api/chat/message`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      })

      if (!response.ok) {
        throw new Error(`FastAPI responded with status: ${response.status}`)
      }

      const data = await response.json()
      return NextResponse.json(data)
    } catch (error) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }
  } catch (error) {
    console.error("Error forwarding request to FastAPI:", error)
    return NextResponse.json({ error: "Failed to process message" }, { status: 500 })
  }
}

