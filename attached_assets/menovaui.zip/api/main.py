from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uuid
from typing import Dict, List, Optional, Union
import time
import jwt
import json
import os
from pymongo import MongoClient
from bson import ObjectId

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize MongoDB client
mongodb_uri = os.environ.get("MONGODB_URI")
client = MongoClient(mongodb_uri)
db = client.get_database()

# JWT secret for verifying tokens
JWT_SECRET = os.environ.get("JWT_SECRET", "your-secret-key")

class MessageRequest(BaseModel):
    userId: str
    message: str

class MessageResponse(BaseModel):
    messageId: str
    responseText: str

# Helper class to convert ObjectId to string
class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return super().default(o)

# Verify JWT token
async def get_current_user(authorization: Union[str, None] = Header(default=None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    try:
        # Extract token from Bearer format
        token = authorization.split(" ")[1]
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        user_id = payload.get("sub")
        
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        # Check if user exists in database
        user = db.users.find_one({"_id": ObjectId(user_id)})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return user_id
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {str(e)}")

# Simulated AI responses based on keywords
def generate_ai_response(user_id: str, message: str) -> str:
    # Simple keyword-based responses
    message_lower = message.lower()
    
    if "sleep" in message_lower:
        return "Sleep disruption is common during menopause. Try these tips:\n• Keep your bedroom cool (65-68°F)\n• Maintain a consistent sleep schedule\n• Avoid screens 1 hour before bed\n• Consider moisture-wicking sheets"
    
    elif "hot flash" in message_lower or "hot flashes" in message_lower:
        return "Hot flashes can be managed with these approaches:\n• Dress in layers you can remove\n• Keep a small fan nearby\n• Stay hydrated\n• Practice deep breathing when a hot flash begins"
    
    elif "mood" in message_lower or "anxiety" in message_lower or "depression" in message_lower:
        return "Mood changes are common during menopause. Consider:\n• Regular exercise\n• Mindfulness meditation\n• Connecting with supportive friends\n• Speaking with a healthcare provider about options"
    
    elif "symptom" in message_lower or "track" in message_lower:
        return "Tracking your symptoms can help identify patterns. Would you like me to help you log a new symptom in your tracker?"
    
    elif "plan" in message_lower or "program" in message_lower:
        return "We have several wellness plans that might help. The Better Sleep Plan has been particularly popular with users experiencing similar symptoms."
    
    elif "hello" in message_lower or "hi" in message_lower:
        # Try to get user's name from profile
        try:
            user = db.users.find_one({"_id": ObjectId(user_id)})
            if user and user.get("fullName"):
                return f"Hello {user['fullName']}! I'm your Menova assistant. How can I help with your menopause journey today?"
        except:
            pass
        
        return f"Hello! I'm your Menova assistant. How can I help with your menopause journey today?"
    
    else:
        return "Thank you for sharing that. Is there anything specific about menopause or your symptoms that you'd like to discuss?"

@app.post("/api/chat/message", response_model=MessageResponse)
async def send_message(request: MessageRequest, user_id: str = Depends(get_current_user)):
    if not request.message:
        raise HTTPException(status_code=400, detail="Message is required")
    
    # Generate a unique message ID
    message_id = str(uuid.uuid4())
    
    # Store user message in database
    try:
        db.chat_messages.insert_one({
            "_id": message_id,
            "user_id": user_id,
            "sender": "user",
            "content": request.message,
            "created_at": time.time()
        })
    except Exception as e:
        print(f"Error storing user message: {e}")
    
    # Generate AI response
    response_text = generate_ai_response(user_id, request.message)
    
    # Add a small delay to simulate processing
    time.sleep(0.5)
    
    # Store AI response in database
    response_id = str(uuid.uuid4())
    try:
        db.chat_messages.insert_one({
            "_id": response_id,
            "user_id": user_id,
            "sender": "ai",
            "content": response_text,
            "created_at": time.time()
        })
    except Exception as e:
        print(f"Error storing AI message: {e}")
    
    return MessageResponse(messageId=response_id, responseText=response_text)

@app.get("/")
async def root():
    return {"message": "Menova.ai Chat API is running"}

