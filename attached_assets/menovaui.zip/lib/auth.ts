import { compare, hash } from "bcryptjs"
import clientPromise from "./mongodb"
import { ObjectId } from "mongodb"

export type User = {
  _id: string | ObjectId
  email: string
  password?: string
  fullName: string
  menopauseStage?: string
  dateOfBirth?: string
  lastPeriodDate?: string
  createdAt: Date
  updatedAt: Date
}

export async function createUser(userData: {
  email: string
  password: string
  fullName: string
}): Promise<Omit<User, "password"> | null> {
  try {
    const client = await clientPromise
    const db = client.db()

    // Check if user already exists
    const existingUser = await db.collection("users").findOne({ email: userData.email })
    if (existingUser) {
      throw new Error("User already exists")
    }

    // Hash the password
    const hashedPassword = await hash(userData.password, 12)

    // Create user object
    const user = {
      email: userData.email,
      password: hashedPassword,
      fullName: userData.fullName,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // Insert user into database
    const result = await db.collection("users").insertOne(user)

    // Return user without password
    const { password, ...userWithoutPassword } = user
    return {
      ...userWithoutPassword,
      _id: result.insertedId,
    } as Omit<User, "password">
  } catch (error) {
    console.error("Error creating user:", error)
    throw error
  }
}

export async function findUserByEmail(email: string): Promise<User | null> {
  try {
    const client = await clientPromise
    const db = client.db()

    return (await db.collection("users").findOne({ email })) as User | null
  } catch (error) {
    console.error("Error finding user:", error)
    throw error
  }
}

export async function findUserById(id: string): Promise<Omit<User, "password"> | null> {
  try {
    const client = await clientPromise
    const db = client.db()

    const user = (await db.collection("users").findOne({ _id: new ObjectId(id) })) as User | null

    if (!user) return null

    // Return user without password
    const { password, ...userWithoutPassword } = user
    return userWithoutPassword
  } catch (error) {
    console.error("Error finding user by ID:", error)
    throw error
  }
}

export async function validatePassword(user: User, inputPassword: string): Promise<boolean> {
  if (!user.password) return false

  return compare(inputPassword, user.password)
}

export async function updateUserProfile(
  userId: string,
  profileData: {
    fullName?: string
    menopauseStage?: string
    dateOfBirth?: string
    lastPeriodDate?: string
  },
): Promise<Omit<User, "password"> | null> {
  try {
    const client = await clientPromise
    const db = client.db()

    const updateData = {
      ...profileData,
      updatedAt: new Date(),
    }

    await db.collection("users").updateOne({ _id: new ObjectId(userId) }, { $set: updateData })

    return await findUserById(userId)
  } catch (error) {
    console.error("Error updating user profile:", error)
    throw error
  }
}

