# Menova.ai with FastAPI Integration

This project integrates a Next.js frontend with a FastAPI backend for the AI chat functionality.

## Setup Instructions

### 1. Start the FastAPI Backend

```bash
cd api
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000

