import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function ChatTab() {
  return (
    <div className="rounded-lg border border-gray-200 p-6 bg-white">
      <h2 className="text-xl font-bold mb-6">AI Chat</h2>

      <div className="space-y-4 mb-6">
        <div className="flex gap-2">
          <Avatar className="w-6 h-6 bg-[#f26158] text-white">
            <AvatarFallback>AI</AvatarFallback>
          </Avatar>
          <div className="bg-gray-100 rounded-lg p-3 text-xs max-w-[80%]">
            <p>Hi Karen, I'm your Menova assistant. How can I help with your menopause journey today?</p>
          </div>
        </div>

        <div className="flex gap-2 justify-end">
          <div className="bg-[#ffd7d0] rounded-lg p-3 text-xs max-w-[80%]">
            <p>I've been having trouble sleeping. Any suggestions?</p>
          </div>
          <Avatar className="w-6 h-6">
            <AvatarFallback>K</AvatarFallback>
          </Avatar>
        </div>

        <div className="flex gap-2">
          <Avatar className="w-6 h-6 bg-[#f26158] text-white">
            <AvatarFallback>AI</AvatarFallback>
          </Avatar>
          <div className="bg-gray-100 rounded-lg p-3 text-xs max-w-[80%]">
            <p>Sleep disruption is common. Try these sleep hygiene tips:</p>
            <ul className="list-disc pl-4 mt-1">
              <li>Consistent bedtime routine</li>
              <li>Cool bedroom temperature</li>
              <li>Avoid screens before bed</li>
              <li>Reduce room light</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="flex gap-2 mb-6">
        <Button variant="outline" className="text-xs flex-1 h-8 rounded-full border-[#f26158] text-[#f26158]">
          Sleep Tips
        </Button>
        <Button variant="outline" className="text-xs flex-1 h-8 rounded-full">
          Track Sleep
        </Button>
      </div>

      <div className="relative">
        <Input placeholder="Type a message..." className="pr-10 rounded-full text-xs" />
        <Button size="sm" className="absolute right-1 top-1 h-6 w-6 rounded-full p-0 bg-[#f26158]">
          <span className="sr-only">Send</span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-4 w-4"
          >
            <path d="M12 5l7 7-7 7"></path>
          </svg>
        </Button>
      </div>
    </div>
  )
}

