import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export default function BlogPost() {
  return (
    <div className="rounded-lg border border-gray-200 p-4 bg-white">
      <h2 className="text-lg font-bold mb-4">Blog Post</h2>

      <div className="mb-4">
        <h3 className="text-base font-bold mb-2">My Journey with Night Sweats</h3>

        <div className="flex items-center gap-2 mb-3">
          <Avatar className="w-6 h-6">
            <AvatarFallback>J</AvatarFallback>
          </Avatar>
          <div>
            <div className="text-xs font-medium">Jennifer W.</div>
            <div className="text-[10px] text-gray-500">Sleep</div>
          </div>
        </div>

        <div className="text-xs space-y-3 mb-4">
          <p>
            For the past year, night sweats were disrupting my sleep and affecting my energy levels. After trying
            several approaches, I finally found relief.
          </p>

          <h4 className="font-medium">What Worked for Me:</h4>
          <ol className="list-decimal pl-4 space-y-1">
            <li>
              Temperature regulation: Keeping my bedroom cooler at night (around 65°F) made a tremendous difference.
            </li>
            <li>
              Evening routine: Using moisture-wicking sheets and wearing breathable fabrics helped manage nighttime
              temperature fluctuations.
            </li>
            <li>
              Stress reduction: Practicing meditation for just 5 minutes before bed helped calm my nervous system and
              reduced night sweats by about 70%.
            </li>
          </ol>
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Comments (36)</h4>

          <div className="border-b pb-2 mb-2">
            <div className="flex items-start gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>S</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-xs font-medium">Sarah W.</div>
                <p className="text-xs">
                  Thanks for sharing! I've been struggling with the same issue and will try your suggestions.
                </p>
                <div className="text-[10px] text-gray-500">Feb 22 • 3 days ago • 14 comments</div>
              </div>
              <Badge className="bg-[#f26158] text-white text-[10px] h-5">Helpful</Badge>
            </div>
          </div>

          <div>
            <div className="flex items-start gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>L</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-xs font-medium">Lisa T.</div>
                <p className="text-xs">Are these cooling pillows? They've been a game-changer for me!</p>
                <div className="text-[10px] text-gray-500">Feb 20 • 5 days ago • 8 comments</div>
              </div>
            </div>
          </div>
        </div>

        <div className="relative">
          <input placeholder="Add a comment..." className="w-full text-xs border rounded-full py-2 px-4 pr-10" />
          <Button size="sm" className="absolute right-1 top-1 h-6 w-6 rounded-full p-0">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-3 w-3"
            >
              <path d="M12 5l7 7-7 7"></path>
            </svg>
          </Button>
        </div>
      </div>
    </div>
  )
}

