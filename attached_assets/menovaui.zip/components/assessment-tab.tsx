import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function AssessmentTab() {
  return (
    <div className="rounded-lg border border-gray-200 p-6 bg-white">
      <div className="flex items-center mb-6">
        <div className="bg-[#ffe18b] rounded-full w-16 h-16 flex items-center justify-center mr-4">
          <span className="text-black font-medium">menova.ai</span>
        </div>
        <div>
          <h2 className="text-xl font-bold">Menova.ai</h2>
          <p className="text-sm text-gray-600">Your personalized menopause companion</p>
        </div>
      </div>

      <p className="text-sm text-gray-500 mb-2">You are not alone in your journey.</p>
      <p className="text-sm text-gray-500 mb-6">Connect with a supportive community.</p>

      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-medium">Assessment</h3>
          <div className="text-xs text-gray-500">Question 1 of 8</div>
        </div>

        <div className="w-full bg-gray-200 h-1 mb-6 rounded-full overflow-hidden">
          <div className="bg-[#f26158] h-1 rounded-full" style={{ width: "12.5%" }}></div>
        </div>

        <h4 className="font-medium mb-4">When was your last period?</h4>

        <RadioGroup defaultValue="option1" className="space-y-3">
          <div className="flex items-center justify-between border rounded-lg p-3">
            <label htmlFor="option1" className="text-sm">
              Within the last month
            </label>
            <RadioGroupItem value="option1" id="option1" />
          </div>

          <div className="flex items-center justify-between border border-[#ffe18b] rounded-lg p-3 bg-[#fffbf0]">
            <label htmlFor="option2" className="text-sm">
              1-3 months ago
            </label>
            <RadioGroupItem value="option2" id="option2" className="border-[#ffe18b] text-[#ffe18b]" />
          </div>

          <div className="flex items-center justify-between border rounded-lg p-3">
            <label htmlFor="option3" className="text-sm">
              4-12 months ago
            </label>
            <RadioGroupItem value="option3" id="option3" />
          </div>

          <div className="flex items-center justify-between border rounded-lg p-3">
            <label htmlFor="option4" className="text-sm">
              Over a year ago
            </label>
            <RadioGroupItem value="option4" id="option4" />
          </div>
        </RadioGroup>
      </div>

      <div className="flex justify-between items-center mb-6">
        <Button variant="outline" className="text-gray-500">
          Back
        </Button>
        <Button className="bg-[#f26158] hover:bg-[#e05048] text-white">Next</Button>
      </div>

      <div className="space-y-3">
        <Button className="w-full bg-[#f26158] hover:bg-[#e05048] text-white">Take Assessment</Button>
        <Button variant="outline" className="w-full">
          Sign In
        </Button>
        <p className="text-xs text-center text-gray-500">Already have an account?</p>
      </div>
    </div>
  )
}

