import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function BetterSleepPlan() {
  return (
    <div className="rounded-lg border border-gray-200 p-4 bg-white">
      <h2 className="text-lg font-bold mb-4">Better Sleep Plan</h2>

      <div className="mb-4">
        <div className="text-sm mb-1">Day 14 of 21</div>
        <div className="flex items-center gap-2 mb-2">
          <div className="text-xs text-[#f26158]">67% complete</div>
          <div className="text-xs text-gray-500">40 participants</div>
        </div>
        <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden mb-4">
          <div className="bg-[#f26158] h-1 rounded-full" style={{ width: "67%" }}></div>
        </div>

        <div className="border rounded-lg p-3 mb-4">
          <h3 className="text-sm font-medium mb-2">Today: Sleep Environment</h3>
          <p className="text-xs mb-2">Adjust bedroom temperature between 65-68°F (18-20°C)</p>
          <p className="text-xs mb-3">Use blackout curtains or an eye mask to eliminate light interference.</p>
          <p className="text-xs text-gray-500 mb-3">Try using a white noise machine to mask disruptive sounds.</p>

          <Button size="sm" className="bg-[#f26158] text-white text-xs w-full">
            Mark Complete
          </Button>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-medium mb-2">Community Progress</h3>
        <div className="flex items-center gap-2 mb-2">
          <div className="w-6 h-6 rounded-full bg-[#f26158]"></div>
          <div className="text-xs">You are here</div>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-gray-200"></div>
          <div className="text-xs">Community Average</div>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium mb-2">Discussion</h3>

        <div className="border-b pb-3 mb-3">
          <div className="flex items-start gap-2 mb-2">
            <Badge className="bg-[#f26158] text-white text-xs h-6 w-6 rounded-full flex items-center justify-center p-0">
              K
            </Badge>
            <div>
              <div className="text-xs font-medium">Karen M.</div>
              <p className="text-xs">I've been using a cooling pad under my sheets and it's made a huge difference!</p>
            </div>
          </div>
        </div>

        <div>
          <div className="flex items-start gap-2 mb-2">
            <Badge className="bg-[#f26158] text-white text-xs h-6 w-6 rounded-full flex items-center justify-center p-0">
              T
            </Badge>
            <div>
              <div className="text-xs font-medium">Tina L.</div>
              <p className="text-xs">The white noise machine suggestion changed my sleep quality completely!</p>
            </div>
          </div>
        </div>

        <div className="mt-4 relative">
          <input
            placeholder="Share your experience..."
            className="w-full text-xs border rounded-full py-2 px-4 pr-10"
          />
          <Button size="sm" className="absolute right-1 top-1 h-6 w-6 rounded-full p-0">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-3 w-3"
            >
              <path d="M12 5l7 7-7 7"></path>
            </svg>
          </Button>
        </div>
      </div>
    </div>
  )
}

