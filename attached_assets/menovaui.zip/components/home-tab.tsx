import { Button } from "@/components/ui/button"

export default function HomeTab() {
  return (
    <div className="rounded-lg border border-gray-200 p-6 bg-white">
      <h2 className="text-xl font-bold mb-6">Home</h2>

      <div className="bg-[#ffd7d0] rounded-lg p-4 mb-6">
        <div className="text-sm font-medium mb-1">Welcome, Karen!</div>
        <div className="text-xs mb-2">You're in Perimenopausal Day #5</div>
        <div className="text-xs">Track your symptoms to get insights.</div>
        <div className="text-xs text-[#f26158] underline cursor-pointer">Take Assessment</div>
      </div>

      <div className="mb-6">
        <h3 className="text-sm font-medium mb-3">Quick Access</h3>
        <div className="flex gap-2">
          <Button variant="outline" className="text-xs flex-1 h-8">
            Log Symptoms
          </Button>
          <Button variant="outline" className="text-xs flex-1 h-8">
            Ask AI Assistant
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-sm font-medium mb-3">Today's Insights</h3>
        <div className="text-xs space-y-2">
          <div>Your sleep pattern has improved</div>
          <div>Hot flashes decreased by 30%</div>
          <div>Mood seems stable this week</div>
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-medium">Community Highlights</h3>
        </div>
        <div className="text-xs mb-1">New discussion: Sleep tips</div>
        <div className="text-xs mb-1">5 responses to your post</div>
        <div className="text-xs text-[#f26158] cursor-pointer">View All</div>
      </div>

      <div className="flex justify-center mt-6 space-x-2">
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} className={`w-2 h-2 rounded-full ${i === 0 ? "bg-[#f26158]" : "bg-gray-200"}`} />
        ))}
      </div>
    </div>
  )
}

