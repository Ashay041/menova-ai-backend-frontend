import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function Community() {
  return (
    <div className="rounded-lg border border-gray-200 p-4 bg-white">
      <h2 className="text-lg font-bold mb-4">Community</h2>

      <Tabs defaultValue="discussions">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="discussions" className="text-xs">
            Discussions
          </TabsTrigger>
          <TabsTrigger value="blogs" className="text-xs">
            Blogs
          </TabsTrigger>
          <TabsTrigger value="content" className="text-xs">
            My Content
          </TabsTrigger>
        </TabsList>

        <TabsContent value="discussions">
          <div className="mb-4">
            <div className="relative mb-4">
              <Input placeholder="Search topics..." className="text-xs pl-8" />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500"
              >
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.3-4.3"></path>
              </svg>
            </div>

            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-medium">Popular Tags</h3>
              <Button variant="ghost" size="sm" className="text-xs h-6">
                Filter
              </Button>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline" className="text-xs">
                Sleep
              </Badge>
              <Badge variant="outline" className="text-xs bg-[#ffd7d0] border-[#ffd7d0]">
                Hot Flashes
              </Badge>
              <Badge variant="outline" className="text-xs">
                Activity
              </Badge>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

