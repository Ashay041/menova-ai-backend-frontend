import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Button } from "@/components/ui/button"

export default function LogSymptom() {
  return (
    <div className="rounded-lg border border-gray-200 p-4 bg-white">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Log Symptom</h2>
        <div className="text-sm text-gray-500">Cairo</div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-medium mb-2">Insomnia</h3>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Severity</h4>
          <RadioGroup defaultValue="moderate" className="flex gap-2">
            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-[#ffd7d0] flex items-center justify-center mb-1">
                <RadioGroupItem value="mild" id="mild" className="sr-only" />
              </div>
              <label htmlFor="mild" className="text-[10px]">
                Mild
              </label>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-white border-2 border-[#f26158] flex items-center justify-center mb-1">
                <RadioGroupItem value="moderate" id="moderate" className="sr-only" />
              </div>
              <label htmlFor="moderate" className="text-[10px]">
                Moderate
              </label>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-white border flex items-center justify-center mb-1">
                <RadioGroupItem value="severe" id="severe" className="sr-only" />
              </div>
              <label htmlFor="severe" className="text-[10px]">
                Severe
              </label>
            </div>
          </RadioGroup>
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Time of Day</h4>
          <RadioGroup defaultValue="evening" className="flex gap-2">
            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-white border flex items-center justify-center mb-1">
                <RadioGroupItem value="morning" id="morning" className="sr-only" />
              </div>
              <label htmlFor="morning" className="text-[10px]">
                Morning
              </label>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-white border flex items-center justify-center mb-1">
                <RadioGroupItem value="afternoon" id="afternoon" className="sr-only" />
              </div>
              <label htmlFor="afternoon" className="text-[10px]">
                Afternoon
              </label>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-[#f26158] flex items-center justify-center mb-1">
                <RadioGroupItem value="evening" id="evening" className="sr-only" />
              </div>
              <label htmlFor="evening" className="text-[10px]">
                Evening
              </label>
            </div>
          </RadioGroup>
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Notes</h4>
          <div className="border rounded-lg p-3 text-xs text-gray-500">
            Had trouble falling asleep before midnight...
          </div>
        </div>

        <div className="mb-4">
          <h4 className="text-xs font-medium mb-2">Recommended For Your Symptoms</h4>
          <div className="border rounded-lg p-3">
            <h5 className="text-xs font-medium mb-1">Better Sleep Plan</h5>
            <p className="text-xs text-gray-500 mb-2">21-day program to improve sleep quality and reduce insomnia</p>
            <Button size="sm" className="bg-[#f26158] text-white text-xs w-full">
              Join Plan
            </Button>
          </div>
        </div>

        <Button size="sm" className="bg-[#f26158] text-white text-xs w-full">
          Save Symptom
        </Button>

        <div className="text-xs text-center text-[#f26158] mt-2 cursor-pointer">
          View Community Stories about Insomnia
        </div>
      </div>
    </div>
  )
}

