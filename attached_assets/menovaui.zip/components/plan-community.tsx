import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function PlanCommunity() {
  return (
    <div className="rounded-lg border border-gray-200 p-4 bg-white">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Plan Community</h2>
        <Badge className="bg-[#f26158] text-white text-xs">See 15 new posts today</Badge>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="all" className="text-xs">
            All Posts
          </TabsTrigger>
          <TabsTrigger value="success" className="text-xs">
            Success Stories
          </TabsTrigger>
          <TabsTrigger value="questions" className="text-xs">
            Questions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="space-y-3">
            <div className="flex gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>K</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <div className="text-sm font-medium">Karen M.</div>
                  <div className="text-xs text-gray-500">May 14</div>
                </div>
                <p className="text-xs mb-1">
                  I've been using a cooling pad under my sheets and it's made a huge difference! My night sweats have
                  reduced by about 70%.
                </p>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">7 replies • 15 minutes ago</div>
                  <Button variant="ghost" size="sm" className="text-xs h-6">
                    Like
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>T</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <div className="text-sm font-medium">Tina L.</div>
                  <div className="text-xs text-gray-500">May 12</div>
                </div>
                <p className="text-xs mb-1">
                  The white noise machine suggestion from Dr. Miller changed my sleep completely! I'm now getting 7
                  hours of uninterrupted sleep.
                </p>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">5 replies • 2 days ago</div>
                  <Button variant="ghost" size="sm" className="text-xs h-6">
                    Like
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback>R</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <div className="text-sm font-medium">Rebecca D.</div>
                  <div className="text-xs text-gray-500">May 10</div>
                </div>
                <p className="text-xs mb-1">
                  Has anyone found a good alternative to traditional HRT? They were too potent for my symptoms.
                </p>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">9 replies • 4 days ago</div>
                  <Button variant="ghost" size="sm" className="text-xs h-6">
                    Like
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <Button className="w-full mt-4 bg-[#ffe18b] text-black hover:bg-[#ffd86b] text-xs">Share Your Experience</Button>
    </div>
  )
}

