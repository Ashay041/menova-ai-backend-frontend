import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SymptomTracker() {
  return (
    <div className="rounded-lg border border-gray-200 p-4 bg-white">
      <h2 className="text-lg font-bold mb-4">Symptom Tracker</h2>

      <Tabs defaultValue="overview">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="overview" className="text-xs">
            Overview
          </TabsTrigger>
          <TabsTrigger value="symptoms" className="text-xs">
            Symptoms
          </TabsTrigger>
          <TabsTrigger value="plans" className="text-xs">
            Plans
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div>
            <h3 className="text-sm font-medium mb-2">Weekly Summary</h3>
            <div className="text-xs text-gray-500 mb-2">This Week</div>

            <div className="mb-4">
              <div className="h-32 w-full bg-gray-50 rounded-lg relative mb-2">
                {/* Chart would go here - simplified with colored lines */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg width="100%" height="100%" viewBox="0 0 200 100" preserveAspectRatio="none">
                    <polyline
                      points="0,80 30,60 60,70 90,40 120,50 150,30 180,20"
                      fill="none"
                      stroke="#f26158"
                      strokeWidth="2"
                    />
                    <polyline
                      points="0,90 30,85 60,80 90,85 120,75 150,80 180,70"
                      fill="none"
                      stroke="#ffe18b"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
              </div>
              <div className="flex justify-between text-[10px] text-gray-500">
                <span>Mon</span>
                <span>Tue</span>
                <span>Wed</span>
                <span>Thu</span>
                <span>Fri</span>
                <span>Sat</span>
                <span>Sun</span>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

