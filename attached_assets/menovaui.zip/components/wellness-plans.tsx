import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function WellnessPlans() {
  return (
    <div className="rounded-lg border border-gray-200 p-4 bg-white">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Wellness Plans</h2>
        <Badge className="bg-[#f26158] text-white text-xs">Recommended</Badge>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-medium mb-2">My Active Plans</h3>

        <div className="border rounded-lg p-3 mb-3">
          <div className="flex justify-between items-center mb-1">
            <h4 className="text-sm font-medium">Better Sleep Plan</h4>
            <Badge className="bg-[#ffe18b] text-black text-[10px]">Discoverer</Badge>
          </div>
          <div className="text-xs text-gray-500 mb-1">Day 14 of 21</div>
          <div className="flex items-center gap-2 mb-1">
            <div className="text-xs text-[#f26158]">67% complete</div>
            <div className="text-xs text-gray-500">40 others</div>
          </div>
          <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden">
            <div className="bg-[#f26158] h-1 rounded-full" style={{ width: "67%" }}></div>
          </div>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-medium mb-2">Find A Plan</h3>

        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-4 w-4"
            >
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.3-4.3"></path>
            </svg>
          </div>
          <Button size="sm" className="bg-[#f26158] text-white text-xs">
            Start
          </Button>
        </div>

        <div className="mb-3">
          <div className="text-xs font-medium mb-2">Based on your tracked symptoms</div>

          <div className="border rounded-lg p-3 mb-2">
            <h4 className="text-sm font-medium mb-1">Hot Flash Relief</h4>
            <p className="text-xs text-gray-500 mb-2">
              4-week program to reduce frequency and intensity of hot flashes
            </p>
            <div className="flex justify-between items-center">
              <Button variant="outline" size="sm" className="text-xs h-6">
                View Details
              </Button>
              <Badge className="bg-[#ffe18b] text-black text-[10px]">Popular</Badge>
            </div>
          </div>

          <div className="border rounded-lg p-3">
            <h4 className="text-sm font-medium mb-1">Brain Fog Clarity</h4>
            <p className="text-xs text-gray-500 mb-2">
              2-week cognitive enhancement program with memory exercises and techniques
            </p>
            <div className="flex justify-between items-center">
              <Button variant="outline" size="sm" className="text-xs h-6">
                View Details
              </Button>
              <Badge className="bg-[#ffe18b] text-black text-[10px]">Popular</Badge>
            </div>
          </div>
        </div>

        <Button variant="outline" size="sm" className="w-full text-xs">
          Browse All Plans
        </Button>
      </div>
    </div>
  )
}

