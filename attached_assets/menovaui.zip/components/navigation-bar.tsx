"use client"

import { Home, MessageCircle, Activity, Users } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

export default function NavigationBar() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    if (path === "/home" && pathname === "/home") return true
    if (path === "/chat" && pathname === "/chat") return true
    if (
      path === "/track" &&
      ["/symptom-tracker", "/log-symptom", "/wellness-plans", "/better-sleep-plan"].includes(pathname)
    )
      return true
    if (path === "/community" && ["/community", "/plan-community", "/blog-post"].includes(pathname)) return true
    return false
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t py-3 px-4 z-10">
      <div className="max-w-md mx-auto">
        <div className="flex justify-between">
          <Link href="/home" className="flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive("/home") ? "bg-[#f26158]" : "bg-gray-200"}`}
            >
              <Home className={`w-5 h-5 ${isActive("/home") ? "text-white" : "text-gray-500"}`} />
            </div>
            <span className={`text-xs mt-1 ${isActive("/home") ? "text-[#f26158]" : "text-gray-500"}`}>Home</span>
          </Link>

          <Link href="/chat" className="flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive("/chat") ? "bg-[#f26158]" : "bg-gray-200"}`}
            >
              <MessageCircle className={`w-5 h-5 ${isActive("/chat") ? "text-white" : "text-gray-500"}`} />
            </div>
            <span className={`text-xs mt-1 ${isActive("/chat") ? "text-[#f26158]" : "text-gray-500"}`}>Chat</span>
          </Link>

          <Link href="/symptom-tracker" className="flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive("/track") ? "bg-[#f26158]" : "bg-gray-200"}`}
            >
              <Activity className={`w-5 h-5 ${isActive("/track") ? "text-white" : "text-gray-500"}`} />
            </div>
            <span className={`text-xs mt-1 ${isActive("/track") ? "text-[#f26158]" : "text-gray-500"}`}>Track</span>
          </Link>

          <Link href="/community" className="flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive("/community") ? "bg-[#f26158]" : "bg-gray-200"}`}
            >
              <Users className={`w-5 h-5 ${isActive("/community") ? "text-white" : "text-gray-500"}`} />
            </div>
            <span className={`text-xs mt-1 ${isActive("/community") ? "text-[#f26158]" : "text-gray-500"}`}>
              Community
            </span>
          </Link>
        </div>
      </div>
    </div>
  )
}

